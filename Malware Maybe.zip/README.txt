If you want to run the Malware run it as Admin perm,
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
Forgot change the New to the New.bat
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**
**WARNING: This is a dangerous file. No joke. Running this file might cause unexpected behavior, including data loss. Proceed at your own risk. Creator of this will not respond to any loss or any damages.**

